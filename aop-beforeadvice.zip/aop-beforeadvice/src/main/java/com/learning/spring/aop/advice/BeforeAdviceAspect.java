package com.learning.spring.aop.advice;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class BeforeAdviceAspect {

	@Before("execution(public * **(..))")
	public void beforeAdviceAspect(JoinPoint jp) {

		System.out.println("Execute Before Advice on method"
				+ jp.getSignature());
	}

}
