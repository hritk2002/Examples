package com.learning.spring.aop.advice;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class AroundAdviceAspect {

	/**
	 * First * representing any return type followed by method name having one
	 * parameter of any type.
	 * 
	 * 
	 * */
	@Around("execution(* aroundAdviceMethod(*))")
	public void aroundAdviceAspect(ProceedingJoinPoint pjp) {

		try {
			pjp.proceed();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Execute around Advice on method   "
				+ pjp.getSignature());
	}

}
