package com.learning.spring.aop.advice;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class AfterAdviceAspect {

	@After("execution( String com.learning.spring.aop.advice.bean.*.*(..))")
	public void afterAdviceAspect(JoinPoint jp) {

		System.out.println("Execute after Advice on method"
				+ jp.getSignature());
	}

}
