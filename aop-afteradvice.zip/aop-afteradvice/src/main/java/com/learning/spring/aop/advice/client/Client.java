package com.learning.spring.aop.advice.client;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.learning.spring.aop.advice.bean.CombinedBean;
import com.learning.spring.aop.advice.configuration.ConfigurationClass;

public class Client {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(
				ConfigurationClass.class);

		CombinedBean bBean = context.getBean(CombinedBean.class);

		bBean.afterAdviceMethod("Hello");

	}
}
