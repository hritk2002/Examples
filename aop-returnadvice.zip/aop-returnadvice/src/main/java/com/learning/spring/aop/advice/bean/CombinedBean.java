package com.learning.spring.aop.advice.bean;

import org.springframework.stereotype.Component;

@Component
public class CombinedBean {

	public String returnAdviceMethod(String name) {
		System.out.print("I am bean object   " + name);
		return name;
	}

}
