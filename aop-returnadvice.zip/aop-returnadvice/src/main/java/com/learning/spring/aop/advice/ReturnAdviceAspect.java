package com.learning.spring.aop.advice;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class ReturnAdviceAspect {

	/**
	 * @pointcut :-This advice will execute for all the public method, returning
	 *           string and are in com.learning.spring.sop package and all
	 *           subpackages and starting with return and having any number of
	 *           parameters of any type or no parameter at all.
	 * 
	 * @returning contains the return value from advised method.
	 * 
	 * */
	@AfterReturning(pointcut = "execution(public String com.learning.spring.aop.*..return*(..))", returning = "returnValue")
	public void aroundAdviceAspect(String returnValue) {

		System.out
				.println("Execute after returning Advice on method which is retuning   "
						+ returnValue);
	}

}
