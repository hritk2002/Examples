package com.learning.spring.aop.advice.bean;

import org.springframework.stereotype.Component;

@Component
public class CombinedBean {

	public void ParameterAdviceMethod(int i, String name) throws Exception {

		System.out.println("Bean object  ");
	}

}
