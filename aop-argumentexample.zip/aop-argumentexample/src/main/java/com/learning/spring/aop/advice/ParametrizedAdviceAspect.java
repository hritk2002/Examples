package com.learning.spring.aop.advice;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class ParametrizedAdviceAspect {

	/**
	 * *
	 * 
	 * @args nuber and sequence of parameters has to be same in agrs's arguments
	 *       and advice argument..
	 * 
	 * */
	@Before("execution(public * com.learning.spring.aop.*..*(..)) && args(p1,p2)")
	public void aroundAdviceAspect(int p1, String p2) {

		System.out
				.println("Printing parameters  name   " + p2 + "  age  " + p1);
	}

}
