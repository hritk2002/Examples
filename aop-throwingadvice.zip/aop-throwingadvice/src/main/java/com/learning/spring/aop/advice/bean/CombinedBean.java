package com.learning.spring.aop.advice.bean;

import org.springframework.stereotype.Component;

@Component
public class CombinedBean {

	public void throwingAdviceMethod(String name) throws Exception {
		System.out.print("I am bean object   " + name);

		throw new Exception("Exception thrown");

	}

}
