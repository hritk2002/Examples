package com.learning.spring.aop.advice;

import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class ThrowingAdviceAspect {

	/**
	 * @pointcut :-This advice will execute for all the public method, returning
	 *           string and are in com.learning.spring.sop package and all
	 *           subpackages and starting with return and having any number of
	 *           parameters of any type or no parameter at all.
	 * 
	 * @throwing throwing exception ex.
	 * 
	 * */
	@AfterThrowing(pointcut = "execution(public * com.learning.spring.aop.*..throwing*(..))", throwing = "ex")
	public void aroundAdviceAspect(Exception ex) {

		System.out
				.println("Printing exception   "
						+ ex);
	}

}
